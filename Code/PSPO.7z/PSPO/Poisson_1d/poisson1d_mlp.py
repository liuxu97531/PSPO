# cython: language_level=3

from sklearn import metrics
import torch
import matplotlib.pyplot as plt
from tqdm import trange
import numpy as np
import torch.nn.functional as F
from torch.utils import data
from default_options import parses
import sys

sys.path.append('..')
from model.mlp import MLP
from utils.Normalization import Normalization

# Load sensor placement method
sys.path.append('../sensor_placement')
from RBF_GA_PSO import GA_optim
import pyximport

pyximport.install()
from rbf.sputils import expand_rows
from rbf.pde.fd import weight_matrix
from rbf.pde.geometry import contains
from rbf.pde.nodes import poisson_disc_nodes, min_energy_nodes

# import pysensors as ps
from pysensors.reconstruction._sspor import SSPOR
from pysensors.basis._svd import SVD
from Data_PSO import ConditionNumberSampler, EnhancedClusteringSampler, DeterminantBasedSampler

np.random.seed(0)
torch.manual_seed(0)

class SensorSolver():
    def __init__(self, args):
        # Define the problem domain with line segments.
        self.spacing, self.n, self.phi, self.order = 0.07, 25, 'phs3', 2  # approximate spacing between nodes;

        self.nodes = np.linspace(-10, 10, 400).reshape(-1, 1)
        self.nodes_f = self.nodes[1:-1]
        self.nodes_bc = np.array([-10, 10]).reshape(-1, 1)
        self.N = self.nodes.shape[0]
        self.N_f = len(self.nodes) - 2
        self.u_exact = np.sin(0.7 * self.nodes) + np.cos(1.5 * self.nodes) - 0.1 * self.nodes
        self.N_obs, self.lambda_penelaty = args.num_obs, 1

        self.var_num = 2
        self.random_loc_num = 100

        # calculate RBF-FD-sensor-optimization weight for A
        self.A_interior = weight_matrix(
            x=self.nodes_f,
            # x=self.nodes,
            p=self.nodes,
            n=self.n,
            diffs=[2],
            phi=self.phi,
            order=self.order)

        self.A_boundary = weight_matrix(
            x=np.array([-10, 10]).reshape(-1, 1),
            p=self.nodes,
            n=1,
            diffs=[0])
        self.A_interior, self.A_boundary = self.A_interior.toarray(), self.A_boundary.toarray()

        ## 在PDE中添加变量约束
        A1_col_0 = np.sin(0.7 * self.nodes_f).reshape(-1, 1)
        A1_col_1 = np.cos(1.5 * self.nodes_f).reshape(-1, 1)

        A2_col, self.A3_col = np.zeros((self.N - self.N_f, self.var_num)), np.zeros((self.N_obs, self.var_num))

        self.A1 = np.concatenate((self.A_interior, A1_col_0, A1_col_1), axis=1)

        ## 添加边界约束
        self.A2 = np.concatenate((self.A_boundary, A2_col), axis=1)
        self.b12 = np.zeros((self.N,))

    def Sensor_optimize(self):
        # GA = GA_optim(N_obs=self.N_obs, N=self.N, A1=self.A1, A2=self.A2, A3_col=self.A3_col, Lambda=2)
        # test_num = 2
        # pop_size, iteration, rep_para = 10, 10000, 0.3
        # fits, _, idx_optima = GA.GA_location(pop_size, iteration, rep_para)
        # print('pop_size:{}, iteration:{}, rep_para:{}'.format(pop_size, iteration, rep_para))
        # plt.plot(np.arange(2, len(fits) + 2).tolist(), fits)
        # plt.xlabel('Iteration')
        # plt.ylabel('Fitness')
        # plt.yscale('log')
        # plt.title('GA')
        # # plt.savefig('./Result/GA{}.png'.format(test_num))
        # plt.show()
        # if not os.path.exists('./Result/Sensor_optima'):
        #     os.makedirs('./Result/Sensor_optima')
        # np.save('./Result/Sensor_optima/fits{}.npy'.format(test_num), fits)
        # np.save('./Result/Sensor_optima/optima_idx{}.npy'.format(test_num), idx_optima)
        idx_optima = np.array([281, 193, 72, 45, 159, 326, 240, 202, 116, 355])  ## optima
        x_obs_optima, y_obs_optima, u_obs_optima = self.nodes[idx_optima], None, self.u_exact[idx_optima]
        X_obs, Y_obs, U_obs = self.nodes, None, self.u_exact
        return idx_optima, x_obs_optima, y_obs_optima, u_obs_optima, X_obs, Y_obs, U_obs

    def comput_error_bond(self, idx, k):
        self.C = np.zeros((self.N_obs, self.N))
        for i, j in enumerate(idx):
            self.C[i, j] = 1
        A3 = np.concatenate((self.C, self.A3_col), axis=1)
        A = np.concatenate((self.A1, self.A2, A3), axis=0)
        conda_A = np.linalg.cond(A)
        error_l, error_u = k / conda_A, conda_A * k
        error_bond = [error_l.item(), error_u.item()]
        return conda_A, error_bond

    def solver_linalg(self):
        A = np.concatenate([self.A_interior, self.A_boundary], axis=0)
        b1 = -0.49 * np.sin(0.7 * self.nodes_f) - 2.25 * np.cos(1.5 * self.nodes_f)
        b2 = np.sin(0.7 * self.nodes_bc) + np.cos(1.5 * self.nodes_bc) - 0.1 * self.nodes_bc
        b = np.concatenate([b1, b2], axis=0)
        u_star, _, _, _ = np.linalg.lstsq(A, b, rcond=-1)
        plt.plot(self.nodes, u_star)
        plt.show()


class DataGenerator(data.Dataset):
    def __init__(self, u, s, batch_size=64):
        'Initialization'
        self.u = torch.Tensor(u)  # input sample
        self.s = torch.Tensor(s)  # labeled Data_total evulated at y (solution measurements, BC/IC conditions, etc.)

        self.N = u.shape[0]
        self.batch_size = batch_size

    def __getitem__(self, index):
        'Generate one batch of Data_total'
        inputs, outputs = self.__data_generation()
        return inputs, outputs

    def __data_generation(self):
        'Generates Data_total containing batch_size samples'
        idx = np.random.choice(self.N, (self.batch_size,), replace=False)
        s = self.s[idx, :]
        u = self.u[idx, :]
        # Construct batch
        inputs = u
        outputs = s
        return inputs, outputs


class Prepare_data():
    def __init__(self, para1, para2, mean=0, std=0):
        print('Generate Data_total')
        self.para1, self.para2 = para1, para2
        self.M = args.pod_basis_num
        self.mean, self.std = mean, std

    def generate_NN_data(self, N_fun, delta_u_obs=0):
        # p = args.num_obs, m = N_fun, n = P
        datas, xgrid = self.data(N_fun)  # datas n x m, xgrid n x 2

        C = np.zeros((args.num_obs, datas.shape[0]))  # p x n
        for i, j in enumerate(args.idx_obs):
            C[i, j] = 1
        u_obs = np.matmul(C, datas).T  # m x p
        u_obs = u_obs + delta_u_obs  # Add noise

        # Data nomalization
        _, Mapping_obs = Normalization.Mapstatic(u_obs)  # Regularize by row
        u_obs_mean = Mapping_obs[0][None, :]  # 2 x p
        u_obs_std = Mapping_obs[1][None, :]  # 2 x p

        _, Mapping = Normalization.Mapstatic(datas.T)  # Regularize by row
        u_mean = Mapping[0][None, :]  # 2 x n
        u_std = Mapping[1][None, :]  # 2 x n

        s = datas.T # m x n
        return u_obs, s, u_obs_mean, u_obs_std, u_mean, u_std

    def data(self, Samples_num=60):
        xgrid = np.linspace(-10, 10, args.P).reshape(-1, 1)
        u = (self.para1[0] / 0.49) * np.sin(0.7 * xgrid) + (self.para2[0] / 2.25) * np.cos(1.5 * xgrid) - 0.1 * xgrid
        for i in range(1, Samples_num):
            u = np.concatenate(
                [u, (self.para1[i] / 0.49) * np.sin(0.7 * xgrid) + (self.para2[i] / 2.25) * np.cos(
                    1.5 * xgrid) - 0.1 * xgrid],
                axis=1)
        # plt.plot(xgrid, u)
        # plt.show()
        return u, xgrid


class Solver(object):
    def __init__(self, u_obs_mean, u_obs_std, u_mean, u_std):
        # Prepare the experiment environment
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # Build neural network
        num_dim = 1

        self.net = MLP(layers=[args.num_obs, 64, 64, 64, args.P]).to(
            self.device)

        # Build optimizer
        self.optimizer = torch.optim.Adam(self.net.parameters(), lr=args.lr)
        # scheduler = torch.optim.lr_scheduler.ExponentialLR(self.optimizer, gamma=0.98)
        self.loss_log = []

        self.u_obs_mean, self.u_obs_std, self.u_mean, self.u_std = \
            torch.tensor(u_obs_mean).float().to(self.device), torch.tensor(u_obs_std).float().to(
                self.device), torch.tensor(u_mean).float().to(self.device), torch.tensor(u_std).float().to(
                self.device)

    def train(self, dataset: torch.utils.data.Dataset, total_iter):
        data_iterator = iter(dataset)
        pbar = trange(total_iter)
        # Main training loop
        for it in pbar:
            # Fetch Data_total
            self.optimizer.zero_grad()
            batch = next(data_iterator)
            inputs, outputs = batch
            u_obs = inputs
            u_obs, outputs = u_obs.to(self.device), outputs.to(self.device)
            # Compute forward pass
            u_obs = (u_obs - self.u_obs_mean) / self.u_obs_std
            s_pred = self.net(u_obs)
            s_pred = s_pred * self.u_std + self.u_mean
            # Compute loss
            loss = F.mse_loss(outputs.flatten(), s_pred.flatten())
            loss.backward()
            self.optimizer.step()
            # self.lr_scheduler.step()
            if it % 1 == 0:
                loss_value = loss.detach().cpu().numpy().item()
                self.loss_log.append(loss.detach().cpu().numpy())
                pbar.set_postfix({'Loss': loss_value})

    def predict_s(self, u_obs):
        u_obs = torch.Tensor(u_obs).to(self.device)
        u_obs = (u_obs - self.u_obs_mean) / self.u_obs_std
        s_pred = self.net(u_obs) * self.u_std + self.u_mean
        return s_pred

    def save(self, filepath_model):
        torch.save(self.net.state_dict(), filepath_model)

    def load(self, filepath_model):
        self.net.load_state_dict(torch.load(filepath_model))

    def plot_loss(self):
        # Plot for loss function
        plt.figure(figsize=(6, 5))
        plt.plot(self.loss_log, lw=2, label='{}{})'.format(args.model, args.sample_method))
        plt.xlabel('Iteration')
        plt.ylabel('Loss')
        plt.yscale('log')
        plt.legend()
        plt.tight_layout()
        np.save('./Result/{}/{}_curve_loss.npy'.format(args.model, args.model), self.loss_log)
        plt.savefig('./Result/{}/{}_curve_loss.png'.format(args.model, args.model))
        plt.show()


if __name__ == '__main__':
    np.random.seed(4)
    torch.manual_seed(4)
    # Configure the arguments
    args = parses()
    args.model = 'mlp'
    args.num_obs = 10
    args.batch_size = 30
    args.pod_basis_num = 10
    args.epochs = 10000
    # args.epochs = 2

    # Prepare dataset
    args.P = 400  # Evaluated at P different locations
    args.N_fun = 80  # N_fun sample functions
    # para1, para2 = 20 * np.random.random((args.N_fun)), 20 * np.random.random((args.N_fun))
    # np.savez('./Result/para_train.npz', para1=para1, para2 = para2)
    Para_train = np.load('./Result/para_train.npz')
    para1, para2 = Para_train['para1'], Para_train['para2']
    prepare_data = Prepare_data(para1, para2)


    # Sensor location
    # Optimize the sensor location by PhysicsSampler(PS)
    # S_Solver = SensorSolver(args)
    # idx_ps, x_obs_ps, y_obs_ps, u_obs_ps, X_exact, Y_exact, U_exact = S_Solver.Sensor_optimize()
    # idx_ps = np.array([45, 72, 116, 159, 193, 202, 240,  281, 326, 355])

    # Optimize the sensor location by ConditionNumberSampler(CNS)
    # QR based SSPOR solver
    # datas, _ = prepare_data.Data_total(args.N_fun) # P x N_fun
    # S_Solver = SSPOR(
    #     basis=SVD(n_basis_modes=10),
    #     n_sensors = args.num_obs
    # )
    # S_Solver.fit(datas.T)   # N_fun x P
    # idx_CNS = S_Solver.get_selected_sensors()
    # # idx_CNS = np.array([46, 78, 113, 146, 159, 243, 259, 301, 325, 364]) # we delete points that are very close (within idx 15) to satisfy uniformity
    # print('CNS', idx_CNS)

    # datas, _ = prepare_data.Data_total(args.N_fun)  # P x N_fun
    # S_Solver = ConditionNumberSampler(Data_total=datas.T, num = 40, n_components=10)
    # idx_CNS = S_Solver.sample() # we delete points that are very close (within idx 15) to satisfy uniformity
    # idx_CNS = np.array([46, 69, 114, 164, 238, 254, 281, 314, 336, 372])

    # datas, _ = prepare_data.Data_total(args.N_fun)  # P x N_fun
    # xgrid = np.linspace(-10, 10, args.P).reshape(-2, 2)
    # S_Solver = EnhancedClusteringSampler(Data_total = datas.T, num = args.num_obs, coor = xgrid, n_clusters=50)
    # idx_ECS = S_Solver.sample()
    # print('ECS', idx_ECS)
    # idx_CNS =  np.array([57, 64, 146, 154, 162, 171, 319, 326, 335, 345])

    # datas, _ = prepare_data.Data_total(args.N_fun)  # P x N_fun
    # xgrid = np.linspace(-10, 10, args.P).reshape(-2, 2)
    # S_Solver = DeterminantBasedSampler(Data_total = datas.T, num = args.num_obs, n_components=10)
    # idx_DBS = S_Solver.sample()
    # print('DBS', idx_DBS)
    # idx_DBS = [2, 7, 8, 9, 11, 13, 15, 72, 251, 329]

    sample_methods = ['PhysicsSampler', 'UniformSampler', 'ConditionNumberSampler']
    idx_obs_total = np.array([[45, 72, 116, 159, 193, 202, 240, 281, 326, 355],
                              [20, 60, 90, 140, 180, 220, 260, 310, 340, 380],
                              [46, 78, 113, 146, 159, 243, 259, 301, 325, 364]])

    noise_scale = [0.01, 0.1, 0.5]

    noise_scale_i = noise_scale[1]

    args.delta_u_obs = np.random.normal(scale=noise_scale_i, size=(args.N_fun, args.num_obs))  # N_fun x num_obs
    for i, idx in enumerate(idx_obs_total):
        # Generate deeonet Data_total
        print(sample_methods[i])
        args.sample_method = sample_methods[i]
        args.idx_obs = idx
        u_obs, s, u_obs_mean, u_obs_std, u_mean, u_std = prepare_data.generate_NN_data(args.N_fun, args.delta_u_obs)
        dataset = DataGenerator(u_obs, s, args.batch_size)
        NN_solver = Solver(u_obs_mean, u_obs_std, u_mean, u_std)

        # Training
        args.filepath_model = './Result/{}/poisson1d_{}_{}_{}_{}_{}.pth'.format(args.model, args.model, args.sample_method, args.num_obs,
                                                                                noise_scale_i, args.epochs)
        NN_solver.train(dataset, args.epochs)
        NN_solver.save(args.filepath_model)
        # NN_solver.plot_loss()
        NN_solver.load(args.filepath_model)

        # Test
        args.N_fun_test = 20
        # para1_test, para2_test = 20 * np.random.random((args.N_fun_test)), 20 * np.random.random((args.N_fun_test)) # in distribution
        # np.savez('./Result/para_test.npz', para1=para1, para2=para2)
        Para_test = np.load('./Result/para_test.npz')
        para1_test, para2_test = Para_test['para1'], Para_test['para2']

        args.delta_u_obs_test = np.random.normal(scale=noise_scale_i, size=(args.N_fun_test, args.num_obs))  # N_fun_test x num_obs
        prepare_test_data = Prepare_data(para1_test, para2_test)
        u_obs_test, datas_test, _, _, _, _ = prepare_test_data.generate_NN_data(args.N_fun_test, args.delta_u_obs_test)  # datas_test, m_test x n

        s_pred = NN_solver.predict_s(u_obs_test).detach().cpu().numpy() #  m_test x n

        Test_error_max_u = metrics.max_error(datas_test.flatten(), s_pred.flatten())
        Test_error_mse_u = metrics.mean_squared_error(datas_test.flatten(), s_pred.flatten())
        Test_error_mae_u = metrics.mean_absolute_error(datas_test.flatten(), s_pred.flatten())
        print('max, mse, mae：', [Test_error_max_u, Test_error_mse_u, Test_error_mae_u])

        xgrid = np.linspace(-10, 10, args.P).reshape(-1, 1)
        for i_test in range(args.N_fun_test):
            plt.plot(xgrid, datas_test[i_test, :], '-.', label='Exact u', lw=2)
            plt.plot(xgrid, s_pred[i_test, :], '--',
                     label='NN u ({})'.format(args.sample_method), lw=2)
            plt.scatter(xgrid[args.idx_obs], u_obs_test[i_test, :], c='k')
            plt.xlabel('x')
            plt.ylabel('s(x)')
            np.savez('./Result/{}/{}_{}_pred_test.npz'.format(args.model, args.model, args.sample_method), xgrid_obs=xgrid[args.idx_obs], u_obs = u_obs_test[i_test, :], datas_test=datas_test[i_test, :][args.idx_obs], xgrid= xgrid, s_pred = s_pred[i_test, :])
        # plt.legend()
        plt.show()
