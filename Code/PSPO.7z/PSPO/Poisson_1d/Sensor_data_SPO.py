# cython: language_level=3

from sklearn import metrics
import torch
import matplotlib.pyplot as plt
from tqdm import trange
import numpy as np
import torch.nn.functional as F
from torch.utils import data
from default_options import parses
import sys

sys.path.append('..')
from model.mlp import MLP
from utils.Normalization import Normalization

# Load sensor placement method
sys.path.append('../sensor_placement')
from RBF_GA_PSO import GA_optim
import pyximport

pyximport.install()
from rbf.sputils import expand_rows
from rbf.pde.fd import weight_matrix
from rbf.pde.geometry import contains
from rbf.pde.nodes import poisson_disc_nodes, min_energy_nodes

# import pysensors as ps
from pysensors.reconstruction._sspor import SSPOR
from pysensors.basis._svd import SVD
from Data_PSO import ConditionNumberSampler, EnhancedClusteringSampler, DeterminantBasedSampler

class Prepare_data():
    def __init__(self, para1, para2, mean=0, std=0):
        print('Generate Data_total')
        self.para1, self.para2 = para1, para2
        self.M = args.pod_basis_num
        self.mean, self.std = mean, std

    def generate_NN_data(self, N_fun, delta_u_obs=0):
        # p = args.num_obs, m = N_fun, n = P
        datas, xgrid = self.data(N_fun)  # datas n x m, xgrid n x 2

        C = np.zeros((args.num_obs, datas.shape[0]))  # p x n
        for i, j in enumerate(args.idx_obs):
            C[i, j] = 1
        u_obs = np.matmul(C, datas).T  # m x p
        u_obs = u_obs + delta_u_obs  # Add noise

        # Data nomalization
        _, Mapping_obs = Normalization.Mapstatic(u_obs)  # Regularize by row
        u_obs_mean = Mapping_obs[0][None, :]  # 2 x p
        u_obs_std = Mapping_obs[1][None, :]  # 2 x p

        _, Mapping = Normalization.Mapstatic(datas.T)  # Regularize by row
        u_mean = Mapping[0][None, :]  # 2 x n
        u_std = Mapping[1][None, :]  # 2 x n

        s = datas.T # m x n
        return u_obs, s, u_obs_mean, u_obs_std, u_mean, u_std

    def data(self, Samples_num=60):
        xgrid = np.linspace(-10, 10, args.P).reshape(-1, 1)
        u = (self.para1[0] / 0.49) * np.sin(0.7 * xgrid) + (self.para2[0] / 2.25) * np.cos(1.5 * xgrid) - 0.1 * xgrid
        for i in range(1, Samples_num):
            u = np.concatenate(
                [u, (self.para1[i] / 0.49) * np.sin(0.7 * xgrid) + (self.para2[i] / 2.25) * np.cos(
                    1.5 * xgrid) - 0.1 * xgrid],
                axis=1)
        # plt.plot(xgrid, u)
        # plt.show()
        return u, xgrid

np.random.seed(0)
torch.manual_seed(0)
if __name__ == '__main__':
    args = parses()
    args.model = 'mlp'
    args.num_obs = 10
    args.batch_size = 30
    args.pod_basis_num = 10
    args.epochs = 10000
    # args.epochs = 2

    # Prepare dataset
    args.P = 400  # Evaluated at P different locations
    args.N_fun = 80  # N_fun sample functions
    # para1, para2 = 20 * np.random.random((args.N_fun)), 20 * np.random.random((args.N_fun))
    # np.savez('./Result/para_train.npz', para1=para1, para2 = para2)
    Para_train = np.load('./Result/para_train.npz')
    para1, para2 = Para_train['para1'], Para_train['para2']
    prepare_data = Prepare_data(para1, para2)
    # Sensor location

    # Optimize the sensor location by ConditionNumberSampler(CNS)
    # QR based SSPOR solver
    datas, _ = prepare_data.data(args.N_fun) # P x N_fun
    S_Solver = SSPOR(
        basis=SVD(n_basis_modes=10),
        n_sensors = args.num_obs
    )
    S_Solver.fit(datas.T)   # N_fun x P
    idx_CNS = S_Solver.get_selected_sensors()
    # idx_CNS = np.array([46, 78, 113, 146, 159, 243, 259, 301, 325, 364]) # we delete points that are very close (within idx 15) to satisfy uniformity
    print('CNS', idx_CNS)

    datas, _ = prepare_data.data(args.N_fun)  # P x N_fun
    S_Solver = ConditionNumberSampler(data=datas.T, num = 40, n_components=10)
    idx_CNS = S_Solver.sample() # we delete points that are very close (within idx 15) to satisfy uniformity
    # idx_CNS = np.array([46, 69, 114, 164, 238, 254, 281, 314, 336, 372])

    # Optimize the sensor location by nhancedClusteringSampler
    datas, _ = prepare_data.data(args.N_fun)  # P x N_fun
    xgrid = np.linspace(-10, 10, args.P).reshape(-1, 1)
    S_Solver = EnhancedClusteringSampler(data = datas.T, num = args.num_obs, coor = xgrid, n_clusters=50)
    idx_ECS = S_Solver.sample()
    print('ECS', idx_ECS)
    # idx_CNS = np.array([57, 64, 146, 154, 162, 171, 319, 326, 335, 345])
