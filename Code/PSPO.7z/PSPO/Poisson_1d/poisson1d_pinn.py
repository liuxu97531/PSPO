# cython: language_level=3

from sklearn import metrics
import torch
import matplotlib.pyplot as plt
from tqdm import trange
import numpy as np
import torch.nn.functional as F
from torch.utils import data
from default_options import parses
import sys

sys.path.append('..')
from model.mlp import MLP
from utils.Normalization import Normalization

# Load sensor placement method
sys.path.append('../sensor_placement')
from RBF_GA_PSO import GA_optim
import pyximport

pyximport.install()
from rbf.sputils import expand_rows
from rbf.pde.fd import weight_matrix
from rbf.pde.geometry import contains
from rbf.pde.nodes import poisson_disc_nodes, min_energy_nodes


# import pysensors as ps
from pysensors.reconstruction._sspor import SSPOR
from pysensors.basis._svd import SVD
from Data_PSO import ConditionNumberSampler

np.random.seed(0)
torch.manual_seed(0)


class SensorSolver():
    def __init__(self, args):
        # Define the problem domain with line segments.
        self.spacing, self.n, self.phi, self.order = 0.07, 25, 'phs3', 2  # approximate spacing between nodes;

        self.nodes = np.linspace(-10, 10, 400).reshape(-1, 1)
        self.nodes_f = self.nodes[1:-1]
        self.nodes_bc = np.array([-10, 10]).reshape(-1, 1)
        self.N = self.nodes.shape[0]
        self.N_f = len(self.nodes) - 2
        self.u_exact = np.sin(0.7 * self.nodes) + np.cos(1.5 * self.nodes) - 0.1 * self.nodes
        self.N_obs, self.lambda_penelaty = args.num_obs, 1

        self.var_num = 2
        self.random_loc_num = 100

        # calculate RBF-FD-sensor-optimization weight for A
        self.A_interior = weight_matrix(
            x=self.nodes_f,
            # x=self.nodes,
            p=self.nodes,
            n=self.n,
            diffs=[2],
            phi=self.phi,
            order=self.order)

        self.A_boundary = weight_matrix(
            x=np.array([-10, 10]).reshape(-1, 1),
            p=self.nodes,
            n=1,
            diffs=[0])
        self.A_interior, self.A_boundary = self.A_interior.toarray(), self.A_boundary.toarray()

        ## 在PDE中添加变量约束
        A1_col_0 = np.sin(0.7 * self.nodes_f).reshape(-1, 1)
        A1_col_1 = np.cos(1.5 * self.nodes_f).reshape(-1, 1)

        A2_col, self.A3_col = np.zeros((self.N - self.N_f, self.var_num)), np.zeros((self.N_obs, self.var_num))

        self.A1 = np.concatenate((self.A_interior, A1_col_0, A1_col_1), axis=1)

        ## 添加边界约束
        self.A2 = np.concatenate((self.A_boundary, A2_col), axis=1)
        self.b12 = np.zeros((self.N,))

    def Sensor_optimize(self):
        # GA = GA_optim(N_obs=self.N_obs, N=self.N, A1=self.A1, A2=self.A2, A3_col=self.A3_col, Lambda=2)
        # test_num = 2
        # pop_size, iteration, rep_para = 10, 10000, 0.3
        # fits, _, idx_optima = GA.GA_location(pop_size, iteration, rep_para)
        # print('pop_size:{}, iteration:{}, rep_para:{}'.format(pop_size, iteration, rep_para))
        # plt.plot(np.arange(2, len(fits) + 2).tolist(), fits)
        # plt.xlabel('Iteration')
        # plt.ylabel('Fitness')
        # plt.yscale('log')
        # plt.title('GA')
        # # plt.savefig('./Result/GA{}.png'.format(test_num))
        # plt.show()
        # if not os.path.exists('./Result/Sensor_optima'):
        #     os.makedirs('./Result/Sensor_optima')
        # np.save('./Result/Sensor_optima/fits{}.npy'.format(test_num), fits)
        # np.save('./Result/Sensor_optima/optima_idx{}.npy'.format(test_num), idx_optima)
        idx_optima = np.array([281, 193, 72, 45, 159, 326, 240, 202, 116, 355])  ## optima
        x_obs_optima, y_obs_optima, u_obs_optima = self.nodes[idx_optima], None, self.u_exact[idx_optima]
        X_obs, Y_obs, U_obs = self.nodes, None, self.u_exact
        return idx_optima, x_obs_optima, y_obs_optima, u_obs_optima, X_obs, Y_obs, U_obs

    def comput_error_bond(self, idx, k):
        self.C = np.zeros((self.N_obs, self.N))
        for i, j in enumerate(idx):
            self.C[i, j] = 1
        A3 = np.concatenate((self.C, self.A3_col), axis=1)
        A = np.concatenate((self.A1, self.A2, A3), axis=0)
        conda_A = np.linalg.cond(A)
        error_l, error_u = k / conda_A, conda_A * k
        error_bond = [error_l.item(), error_u.item()]
        return conda_A, error_bond

    def solver_linalg(self):
        A = np.concatenate([self.A_interior, self.A_boundary], axis=0)
        b1 = -0.49 * np.sin(0.7 * self.nodes_f) - 2.25 * np.cos(1.5 * self.nodes_f)
        b2 = np.sin(0.7 * self.nodes_bc) + np.cos(1.5 * self.nodes_bc) - 0.1 * self.nodes_bc
        b = np.concatenate([b1, b2], axis=0)
        u_star, _, _, _ = np.linalg.lstsq(A, b, rcond=-1)
        plt.plot(self.nodes, u_star)
        plt.show()


class Prepare_data():
    def __init__(self, para1, para2, mean=0, std=0):
        print('Generate Data_total')
        self.para1, self.para2 = para1, para2
        self.M = args.pod_basis_num
        self.mean, self.std = mean, std

    def generate_NN_data(self, N_fun, delta_u_obs=0):
        # p = args.num_obs, m = N_fun, n = P
        datas, xgrid = self.data(N_fun)  # datas n x m, xgrid n x 2

        C = np.zeros((args.num_obs, datas.shape[0]))  # p x n
        for i, j in enumerate(args.idx_obs):
            C[i, j] = 1
        u_obs = np.matmul(C, datas).T  # m x p
        u_obs = u_obs + delta_u_obs  # Add noise

        # Data nomalization
        _, Mapping_obs = Normalization.Mapstatic(u_obs)  # Regularize by row
        u_obs_mean = Mapping_obs[0][None, :]  # 2 x p
        u_obs_std = Mapping_obs[1][None, :]  # 2 x p

        _, Mapping = Normalization.Mapstatic(datas.T)  # Regularize by row
        u_mean = Mapping[0][None, :]  # 2 x n
        u_std = Mapping[1][None, :]  # 2 x n

        s = datas.T # m x n
        return u_obs, s, u_obs_mean, u_obs_std, u_mean, u_std

    def data(self, Samples_num=60):
        xgrid = np.linspace(-10, 10, args.P).reshape(-1, 1)
        u = (self.para1[0] / 0.49) * np.sin(0.7 * xgrid) + (self.para2[0] / 2.25) * np.cos(1.5 * xgrid) - 0.1 * xgrid
        for i in range(1, Samples_num):
            u = np.concatenate(
                [u, (self.para1[i] / 0.49) * np.sin(0.7 * xgrid) + (self.para2[i] / 2.25) * np.cos(
                    1.5 * xgrid) - 0.1 * xgrid],
                axis=1)
        # plt.plot(xgrid, u)
        # plt.show()
        return u, xgrid


class Solver(object):
    def __init__(self):
        ## environment
        ### if there is GPU, then device will be GPU otherwise CPU
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print("training on ", self.device)
        # Generate Data_total
        xgrid = np.linspace(-10, 10, args.P).reshape(-1, 1)
        x_obs = torch.Tensor(xgrid[args.idx_obs]).reshape(-1, 1)
        exact_fun = lambda x: torch.sin(0.7 * x) + torch.cos(1.5 * x) - 0.1 * x
        u_obs = exact_fun(x_obs) + torch.Tensor(args.delta_u_obs).float()
        self.x_obs, self.u_obs = x_obs.reshape(-1, 1).to(self.device).requires_grad_(True), u_obs.reshape(-1, 1).to(self.device).requires_grad_(True)

        self.u_para1, self.u_para2 = 0.49, 2.25

        ### training papameter
        self.N_b, self.N_u, self.N_f = 2, len(self.u_obs), 4000
        self.w_f, self.w_b, self.w_u = 1, 1, 1
        self.c_history = []

        self.net = MLP(layers=[1, 64, 64, 64, 1]).to(self.device)
        self.optimizer = torch.optim.Adam(self.net.parameters(), lr=args.lr)
        # scheduler = torch.optim.lr_scheduler.ExponentialLR(self.optimizer, gamma=0.98)

        ### Put inverse parameter into optimizer
        para1, para2 = np.array([0]), np.array([0])
        self.para1 = torch.from_numpy(para1).float().to(self.device).requires_grad_(True)
        self.optimizer.add_param_group({'params': self.para1, 'lr': 0.001})

        self.para2 = torch.from_numpy(para2).float().to(self.device).requires_grad_(True)
        self.optimizer.add_param_group({'params': self.para2, 'lr': 0.001})
        self.loss_log = []

    def train(self):

        for epoch in range(args.epochs):
            self.optimizer.zero_grad()
            ### PDE loss
            x_f = ((10 + (-10)) / 2 + (10 + 10) *
                   (torch.rand(size=(self.N_f, 1), dtype=torch.float, device=self.device) - 0.5)
                   ).requires_grad_(True)
            u_f = self.net(x_f)
            PDE_f = self.f_para(u_f, x_f, self.para1, self.para2)
            mse_f = F.mse_loss(PDE_f, torch.zeros_like(PDE_f))
            x_b = torch.Tensor([-10, 10]).reshape(-1, 1).to(self.device).requires_grad_(True)
            u_b = self.net(x_b)
            mse_b = F.mse_loss(u_b, self.Ground_true(x_b))
            ### Data loss
            u_obs_pred = self.net(self.x_obs)
            mse_u = F.mse_loss(u_obs_pred, self.u_obs)
            ### Total_loss
            Total_loss = mse_f + mse_u + mse_b
            Total_loss.backward()
            self.optimizer.step()

            if ((epoch + 1) % 2000 == 0):
                print('epoch:{:05d}, mse_f: {:.08e}, mse_u: {:.08e},Totalloss: {:.08e}'.format(
                    epoch + 1, mse_f.item(), mse_u.item(), Total_loss.item()))
                print('para1:{},para2:{}'.format(self.para1.reshape(1, -1).item(), self.para2.reshape(1, -1).item()))

            ## plot the predition
            if (epoch + 1) % 4000 == 0:
                xx = torch.linspace(-10, 10, 1000).reshape((-1, 1)).to(self.device)
                yy = self.net(xx)
                zz = self.Ground_true(xx)
                xx = xx.reshape((-1)).data.detach().cpu().numpy()
                yy = yy.reshape((-1)).data.detach().cpu().numpy()
                zz = zz.reshape((-1)).data.detach().cpu().numpy()

                plt.cla()
                plt.plot(xx, yy, label='PINN')
                plt.plot(xx, zz, label='Exact', color='r')
                plt.scatter(self.x_obs.cpu().detach().numpy(), self.u_obs.cpu().detach().numpy(), c='k')
                plt.legend()
                plt.title('PINN')
                plt.show()

            # 记录损失, 第一项为残差损失，第二项为边界损失，第三项为Data损失
            self.loss_log.append([mse_f.item(), mse_u.item(), Total_loss.item()])
            # self.c_history.append(c.item())

    def f_para(self, u, x, para1, para2):
        return self.d(self.d(u, x), x) + para1 * torch.sin(0.7 * x) + para2 * torch.cos(1.5 * x)

    def d(self, u, x):
        return torch.autograd.grad(u, x, grad_outputs=torch.ones_like(u), create_graph=True, only_inputs=True, allow_unused=True)[0]

    def predict_s(self, x):
        s_pred = self.net(x.to(self.device))
        return s_pred

    def save(self, filepath_model):
        torch.save(self.net.state_dict(), filepath_model)

    def load(self, filepath_model):
        self.net.load_state_dict(torch.load(filepath_model))

    def Ground_true(self, x):
        return torch.sin(0.7 * x) + torch.cos(1.5 * x) - 0.1 * x

    def plot_loss(self):
        # Plot for loss function
        plt.figure(figsize=(6, 5))
        plt.plot(self.loss_log, lw=2, label='NN({})'.format(args.sample_method))
        plt.xlabel('Iteration')
        plt.ylabel('Loss')
        plt.yscale('log')
        plt.legend()
        plt.tight_layout()
        np.save('./Result/NN_curve_loss_{}.npy'.format(args.sample_method), self.loss_log)
        plt.savefig('./Result/NN_curve_loss_{}.png'.format(args.sample_method))
        plt.show()


if __name__ == '__main__':

    # Configure the arguments
    args = parses()
    args.model = 'pinn'
    args.num_obs = 10
    args.batch_size = 30
    args.pod_basis_num = 10
    args.epochs = 4000
    # args.epochs = 2
    args.P = 400  # Evaluated at P different locations

    # Prepare dataset
    # args.N_fun = 30  # N_fun sample functions
    # para1, para2 = 20 * np.random.random((args.N_fun)), 20 * np.random.random((args.N_fun))
    # prepare_data = Prepare_data(para1, para2)
    # Sensor location
    # Optimize the sensor location by PhysicsSampler(PS)
    # S_Solver = SensorSolver(args)
    # idx_ps, x_obs_ps, y_obs_ps, u_obs_ps, X_exact, Y_exact, U_exact = S_Solver.Sensor_optimize()
    # idx_ps = np.array([45, 72, 116, 159, 193, 202, 240,  281, 326, 355])

    # Optimize the sensor location by ConditionNumberSampler(CNS)
    # QR based SSPOR solver
    # datas, _ = prepare_data.Data_total(args.N_fun) # P x N_fun
    # S_Solver = SSPOR(
    #     basis=SVD(n_basis_modes=10),
    #     # n_sensors = 20
    # )
    # S_Solver.fit(datas.T)   # N_fun x P
    # idx_CNS = S_Solver.get_selected_sensors()
    # idx_CNS = np.array([46, 78, 113, 146, 159, 243, 259, 301, 325, 364]) # we delete points that are very close (within idx 15) to satisfy uniformity

    # datas, _ = prepare_data.Data_total(args.N_fun)  # P x N_fun
    # S_Solver = ConditionNumberSampler(Data_total=datas.T, num = 40, n_components=10)
    # idx_CNS = S_Solver.sample() # we delete points that are very close (within idx 15) to satisfy uniformity
    # idx_CNS = np.array([46, 69, 114, 164, 238, 254, 281, 314, 336, 372])

    sample_methods = ['PhysicsSampler', 'UniformSampler', 'ConditionNumberSampler']
    idx_obs_total = np.array([[45, 72, 116, 159, 193, 202, 240, 281, 326, 355],
                              [20, 60, 90, 140, 180, 220, 260, 310, 340, 380],
                              [46, 78, 113, 146, 159, 243, 259, 301, 325, 364]])

    noise_scale = [0.01, 0.1, 0.2]
    noise_scale_i = noise_scale[0]

    args.delta_u_obs = np.random.normal(scale=noise_scale_i, size=(args.num_obs, 1))  # N_fun x num_obs
    for i, idx in enumerate(idx_obs_total):
        # Generate deeonet Data_total
        print(sample_methods[i])
        args.sample_method = sample_methods[i]
        args.idx_obs = idx

        NN_solver = Solver()
        # Training
        args.filepath_model = './Result/{}/poisson1d_{}_{}_{}_{}_{}.pth'.format(args.model, args.model,
                                                                                args.sample_method, args.num_obs,
                                                                                noise_scale_i, args.epochs)
        NN_solver.train()
        NN_solver.save(args.filepath_model)
        NN_solver.plot_loss()
        # NN_solver.load(args.filepath_model)

        # Test
        xgrid = torch.linspace(-10, 10, args.P).reshape(-1, 1)

        exact_fun = lambda x: torch.sin(0.7 * x) + torch.cos(1.5 * x) - 0.1 * x
        s_exact = exact_fun(xgrid).numpy()
        s_pred = NN_solver.predict_s(xgrid).detach().cpu().numpy() #  m_test x n

        Test_error_max_u = metrics.max_error(s_exact.flatten(), s_pred.flatten())
        Test_error_mse_u = metrics.mean_squared_error(s_exact.flatten(), s_pred.flatten())
        Test_error_mae_u = metrics.mean_absolute_error(s_exact.flatten(), s_pred.flatten())
        print('max, mse, mae：', [Test_error_max_u, Test_error_mse_u, Test_error_mae_u])

        plt.plot(xgrid.numpy(), s_exact, '-.', label='Exact u', lw=2)
        plt.plot(xgrid, s_pred, '--', label='PINN u ({})'.format(args.sample_method), lw=2)
        plt.scatter(xgrid[args.idx_obs], s_exact[args.idx_obs], c='k')
        plt.xlabel('x')
        plt.ylabel('s(x)')
        plt.legend()
        plt.show()

