# cython: language_level=3
import os
from sklearn import metrics
import torch
import matplotlib.pyplot as plt
from tqdm import trange
import numpy as np
import torch.nn.functional as F
from torch.utils import data
from default_options import parses
import sys

sys.path.append('..')
from model.mlp import MLP
from utils.Normalization import Normalization

# Load sensor placement method
sys.path.append('../sensor_placement')
from RBF_GA_PSO import GA_optim
import pyximport

pyximport.install()
from rbf.sputils import expand_rows
from rbf.pde.fd import weight_matrix
from rbf.pde.geometry import contains
from rbf.pde.nodes import poisson_disc_nodes, min_energy_nodes

# import pysensors as ps
from pysensors.reconstruction._sspor import SSPOR
from pysensors.basis._svd import SVD
from Data_PSO import ConditionNumberSampler, EnhancedClusteringSampler, DeterminantBasedSampler

np.random.seed(0)
torch.manual_seed(0)

class SensorSolver():
    def __init__(self, args):
        # Define the problem domain with line segments.
        self.spacing, self.n, self.phi, self.order = 0.07, 25, 'phs3', 2  # approximate spacing between nodes;

        self.nodes = np.linspace(-10, 10, 400).reshape(-1, 1)
        self.nodes_f = self.nodes[1:-1]
        self.nodes_bc = np.array([-10, 10]).reshape(-1, 1)
        self.N = self.nodes.shape[0]
        self.N_f = len(self.nodes) - 2
        self.u_exact = np.sin(0.7 * self.nodes) + np.cos(1.5 * self.nodes) - 0.1 * self.nodes
        self.N_obs, self.lambda_penelaty = args.num_obs, 1

        self.var_num = 2
        self.random_loc_num = 100

        # calculate RBF-FD-sensor-optimization weight for A
        self.A_interior = weight_matrix(
            x=self.nodes_f,
            # x=self.nodes,
            p=self.nodes,
            n=self.n,
            diffs=[2],
            phi=self.phi,
            order=self.order)

        self.A_boundary = weight_matrix(
            x=np.array([-10, 10]).reshape(-1, 1),
            p=self.nodes,
            n=1,
            diffs=[0])
        self.A_interior, self.A_boundary = self.A_interior.toarray(), self.A_boundary.toarray()

        ## 在PDE中添加变量约束
        A1_col_0 = np.sin(0.7 * self.nodes_f).reshape(-1, 1)
        A1_col_1 = np.cos(1.5 * self.nodes_f).reshape(-1, 1)

        A2_col, self.A3_col = np.zeros((self.N - self.N_f, self.var_num)), np.zeros((self.N_obs, self.var_num))

        self.A1 = np.concatenate((self.A_interior, A1_col_0, A1_col_1), axis=1)

        ## 添加边界约束
        self.A2 = np.concatenate((self.A_boundary, A2_col), axis=1)
        self.b12 = np.zeros((self.N,))

    def Sensor_optimize(self):
        GA = GA_optim(N_obs=self.N_obs, N=self.N, A1=self.A1, A2=self.A2, A3_col=self.A3_col, Lambda=1)
        test_num = 1
        # pop_size, iteration, rep_para = 10, 10000, 0.3
        pop_size, iteration, rep_para = 10, 800, 0.3
        fits, _, idx_optima = GA.GA_location(pop_size, iteration, rep_para, 400)
        print('pop_size:{}, iteration:{}, rep_para:{}'.format(pop_size, iteration, rep_para))
        plt.plot(np.arange(1, len(fits) + 1).tolist(), fits)
        plt.xlabel('Iteration')
        plt.ylabel('Fitness')
        plt.yscale('log')
        plt.title('GA')
        # plt.savefig('./Result/Sensor_optima/Sensor_{}_GA{}.png'.format(args.num_obs, test_num))
        plt.show()
        if not os.path.exists('./Result/Sensor_optima'):
            os.makedirs('./Result/Sensor_optima')
        # np.save('./Result/Sensor_optima/Sensor_{}_fits{}.npy'.format(args.num_obs, test_num), fits)
        # np.save('./Result/Sensor_optima/Sensor_{}_optima_idx{}.npy'.format(args.num_obs, test_num), idx_optima)
        # idx_optima = np.array([281, 193, 72, 45, 159, 326, 240, 202, 116, 355])  ## optima
        x_obs_optima, y_obs_optima, u_obs_optima = self.nodes[idx_optima], None, self.u_exact[idx_optima]
        X_obs, Y_obs, U_obs = self.nodes, None, self.u_exact
        return idx_optima, x_obs_optima, y_obs_optima, u_obs_optima, X_obs, Y_obs, U_obs

    def comput_error_bond(self, idx, k):
        self.C = np.zeros((self.N_obs, self.N))
        for i, j in enumerate(idx):
            self.C[i, j] = 1
        A3 = np.concatenate((self.C, self.A3_col), axis=1)
        A = np.concatenate((self.A1, self.A2, A3), axis=0)
        conda_A = np.linalg.cond(A)
        error_l, error_u = k / conda_A, conda_A * k
        error_bond = [error_l.item(), error_u.item()]
        return conda_A, error_bond

    def solver_linalg(self):
        A = np.concatenate([self.A_interior, self.A_boundary], axis=0)
        b1 = -0.49 * np.sin(0.7 * self.nodes_f) - 2.25 * np.cos(1.5 * self.nodes_f)
        b2 = np.sin(0.7 * self.nodes_bc) + np.cos(1.5 * self.nodes_bc) - 0.1 * self.nodes_bc
        b = np.concatenate([b1, b2], axis=0)
        u_star, _, _, _ = np.linalg.lstsq(A, b, rcond=-1)
        plt.plot(self.nodes, u_star)
        plt.show()

if __name__ == '__main__':
    # Optimize the sensor location by PhysicsSampler(PS)
    args = parses()
    args.model = 'mlp'
    args.num_obs = 5
    args.batch_size = 30
    args.pod_basis_num = 10
    args.epochs = 10000

    print("PSPO: obs num {}".format(args.num_obs))
    import time
    start = time.perf_counter()
    S_Solver = SensorSolver(args)
    # idx_ps, x_obs_ps, y_obs_ps, u_obs_ps, X_exact, Y_exact, U_exact = S_Solver.Sensor_optimize()
    end = time.perf_counter()
    runTime = end - start
    print("运行时间：", runTime)
    # idx_ps = np.array([45, 72, 116, 159, 193, 202, 240,  281, 326, 355])
    # idx = [42, 139, 278, 233, 340]
    import time
    start = time.perf_counter()
    # idx = np.linspace(0,400, args.num_obs+2, endpoint=True).astype(int).tolist()[1:-1]
    idx = (400*np.random.rand(args.num_obs)).astype(int).tolist()
    runTime = end - start
    print("运行时间1：", runTime)
    conda_A = S_Solver.comput_error_bond(idx,1)

    print(np.log(np.array(conda_A[0])))

    # (42499.1504058897, [2.3529882137630122e-05, 42499.1504058897])