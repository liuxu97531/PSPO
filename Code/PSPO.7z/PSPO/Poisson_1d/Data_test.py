# cython: language_level=3
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
import matplotlib.pyplot as plt
from numpy import random, mat
from scipy import sparse
import sys
from sklearn import metrics
import matplotlib.tri as tri
import copy
# from deap import creator, base, tools
import torch
import torch.nn as nn
import os
import matplotlib.pyplot as plt

import numpy as np
import csv
from torch.autograd import grad

import sys



from sklearn import metrics
import torch
import matplotlib.pyplot as plt
from tqdm import trange
import numpy as np
import torch.nn.functional as F
from torch.utils import data
from default_options import parses
import sys

sys.path.append('..')
from model.mlp import MLP
from utils.Normalization import Normalization

# Load sensor placement method
sys.path.append('../sensor_placement')
from RBF_GA_PSO import GA_optim
import pyximport

pyximport.install()
from rbf.sputils import expand_rows
from rbf.pde.fd import weight_matrix
from rbf.pde.geometry import contains
from rbf.pde.nodes import poisson_disc_nodes, min_energy_nodes

# import pysensors as ps
from pysensors.reconstruction._sspor import SSPOR
from pysensors.basis._svd import SVD
from Data_PSO import ConditionNumberSampler, EnhancedClusteringSampler, DeterminantBasedSampler, RandomSampler


def Ground_true(x):
    return (para1 / 0.49)*torch.sin(0.7 * x) + (para2 / 2.25)*torch.cos(1.5 * x) - 0.1 * x

para1_test, para2_test = np.array([0.49]), np.array([2.25])

for i in range(len(para1_test)):
    print(i)
    para1, para2 = para1_test[i], para2_test[i]
    xx = torch.linspace(-10, 10, 400).reshape((-1, 1))
    u_truth = Ground_true(xx).cpu().detach().numpy().reshape(-1, 1)
    # idx = [45, 72, 116, 159, 193, 202, 240,  281, 326, 355]
    idx = [42, 139, 278, 233, 350]
    # idx = [15, 65, 69, 72, 243, 249, 251, 325, 326, 329]

    idx_QR = [46, 78, 113, 146, 159, 243, 259, 301, 325, 364]

    x_obs_QR = xx[idx_QR]
    u_obs_QR = Ground_true(x_obs_QR)
    x_obs = xx[idx]
    u_obs = Ground_true(x_obs)
    # plt.scatter(x_obs_QR.cpu().detach().numpy(), u_obs_QR.cpu().detach().numpy(), c='r')
    plt.scatter(x_obs.cpu().detach().numpy(), u_obs.cpu().detach().numpy(), c='b')
    plt.plot(xx, u_truth, label='Exact', color='r')
plt.show()
