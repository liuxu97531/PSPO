This is a package of old and/or incomplete modules which I am no 
longer using or developing. Do not anticipate any more documentation 
than what already exists for these modules.
