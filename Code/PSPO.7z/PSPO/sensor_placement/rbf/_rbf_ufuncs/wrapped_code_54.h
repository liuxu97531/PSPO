/******************************************************************************
 *                       Code generated with sympy 1.9                        *
 *                                                                            *
 *              See http://www.sympy.org/ for more information.               *
 *                                                                            *
 *                      This file is part of 'ufuncify'                       *
 ******************************************************************************/


#ifndef UFUNCIFY__WRAPPED_CODE_54__H
#define UFUNCIFY__WRAPPED_CODE_54__H

double autofunc0(double x0, double c0, double eps);

#endif

