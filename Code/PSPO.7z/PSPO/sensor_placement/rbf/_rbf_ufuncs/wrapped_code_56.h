/******************************************************************************
 *                       Code generated with sympy 1.9                        *
 *                                                                            *
 *              See http://www.sympy.org/ for more information.               *
 *                                                                            *
 *                      This file is part of 'ufuncify'                       *
 ******************************************************************************/


#ifndef UFUNCIFY__WRAPPED_CODE_56__H
#define UFUNCIFY__WRAPPED_CODE_56__H

double autofunc0(double x0, double x1, double x2, double c0, double c1, double c2, double eps);

#endif

