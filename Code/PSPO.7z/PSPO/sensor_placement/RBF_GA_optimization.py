import copy
from deap import creator, base, tools
import numpy as np

class GA_optim():
    def __init__(self, N_obs, N, A1, A2, A3_col,Lambda=1):
        self.N_obs = N_obs
        self.N = N
        self.A1 = A1
        self.A2 = A2
        self.A3_col = A3_col
        self.Lambda = Lambda
    def get_fitness(self, ind):
        # 添加观测约束
        self.C = np.zeros((self.N_obs, self.N))
        for i, j in enumerate(ind):
            self.C[i, j] = 1*self.Lambda
        A3 = np.concatenate((self.C, self.A3_col), axis=1)
        A = np.concatenate((self.A1, self.A2, A3), axis=0)
        conda_A = np.linalg.cond(A)
        return conda_A

    def evaluate_pop(self, pop):
        for ind in pop:
            ind.fitness.values = [self.get_fitness(ind)]

    # 初始化个体
    def int_ind(self, low, up, dim):
        ind = np.random.randint(low, up, dim)
        return ind.tolist()

    # pop_size, the size of population
    # iteration, termination conditions
    # dim, the dimension of optimization problem
    def GA_location(self, pop_size, iteration, rep_para):
        dim = self.N_obs
        low = 0
        up = self.N - 1

        # 定义问题，-1最小化
        creator.create('FitnessMin', base.Fitness, weights=(-1.0,))
        creator.create('Individual', list, fitness=creator.FitnessMin)
        # 定义参数，toolbox存储基本的参数
        toolbox = base.Toolbox()
        toolbox.register('attr_int', self.int_ind, low=low, up=up, dim=dim)
        toolbox.register('individual', tools.initIterate, creator.Individual, toolbox.attr_int)
        toolbox.register('population', tools.initRepeat, list, toolbox.individual)
        # 交叉变异的概率
        # cidx = 0.9
        cidx = 0.7
        # midx = 1 / dim
        midx = 1 / 8
        # 初始种群
        pop = toolbox.population(pop_size)
        self.evaluate_pop(pop)
        fits = []
        for i in range(iteration):
            print('iteration:{}'.format(i))
            offspring = self.reproduction(pop, cidx, midx, low, up, dim, rep_para)
            self.evaluate_pop(offspring)
            pop = tools.selBest(pop + offspring, pop_size)
            fits.append(pop[0].fitness.values[0])
            print('这是最好的位置{},最好目标函数值{}'.format(pop[0], pop[0].fitness.values[0]))

        return fits, pop[0].fitness.values[0], pop[0]

    # 交叉变异
    def reproduction(self, parent, cidx, midx, low, up, dim, rep_para):
        middle = int(len(parent) / 2)
        offspring = []

        for i in range(middle):
            # 两个父代个体
            p1 = copy.deepcopy(parent[i])
            p2 = copy.deepcopy(parent[middle + i])
            idx = np.random.uniform(0, 1)
            if idx < cidx:
                o1, o2 = tools.cxUniform(p1, p2, rep_para)
                offspring.append(copy.deepcopy(o1))
                offspring.append(copy.deepcopy(o2))
            # else:
            #     offspring.append(p1)
            #     offspring.append(p2)

        for j in range(len(offspring)):
            for k in range(len(offspring[j])):
                idx = np.random.uniform(0, 1)
                if idx < midx:
                    offspring[j][k] = np.random.randint(low, up, dim)[0]

        return offspring