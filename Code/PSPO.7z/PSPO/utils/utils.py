import torch
import numpy as np

def flowmeter_get_noise_data(noise_scale, N_fun_test, num_obs, noise_type="none"):
    np.random.seed(0)
    if noise_type == "none":
        return 0
    elif noise_type == "normal":
        eps = np.random.normal(scale=noise_scale, size=(N_fun_test, num_obs))
        return eps
    elif noise_type == "contamined":
        eps1 = np.random.normal(scale=noise_scale, size=(N_fun_test, num_obs))
        eps2 = np.random.normal(scale=10*noise_scale, size=(N_fun_test, num_obs))
        return 0.8*eps1+0.2*eps2
    elif noise_type == "cauchy":
        eps = np.random.standard_cauchy(size=(N_fun_test, num_obs)) * noise_scale
        return eps
    else:
        raise NotImplementedError(f'noise type {noise_type} not implemented.')

if __name__ == '__main__':
    # eps = flowmeter_get_noise_data(0.01, 1000, 10, noise_type="cauchy")
    eps = np.random.poisson(0.1, 1000)
    print(1)
